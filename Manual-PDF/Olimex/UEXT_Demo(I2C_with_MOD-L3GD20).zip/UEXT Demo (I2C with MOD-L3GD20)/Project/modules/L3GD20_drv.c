/*************************************************************************
 *
 *    Used with IAR for ARM 6.30.7
 *
 *    File name   : L3GD20_drv.c
 *    Description : Gyroscope L3GD20 driver source file
 *
 *    History :
 *    1. Date        : June 28, 2013
 *       Author      : Stanimir Petev
 *       Description : Create.
 *                     Based on Accelerometer sensor LIS3L020 driver source file
 *                     by Stanimir Bonev
 *
 **************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "L3GD20_drv.h"
#include "i2c1_drv.h"
/* Private typedef -----------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/*******************************************************************************
* Function Name  : L3GD20_Init
* Description    : Init L3GD20 sensor
* Input          : None
* Output         : None
* Return         : Boolean.
*******************************************************************************/
Boolean L3GD20_Init (void)
{
  u8 Data[2];

  // Enable GPIOB (I2C1) port - PB8 -> SCL; PB9 -> SDA
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  RCC_AHB1PeriphResetCmd(RCC_AHB1Periph_GPIOB, DISABLE);
  
  if(FALSE == I2C1_Open())
    return(FALSE);
  
  L3GD20_Read (WHO_AM_I, Data, 1);
  if(0xD4 != Data[0]) // 0xD4 is the ID of the gyroscope
  {
    I2C1_Close();
    return(FALSE);
  }
  
  L3GD20_Write (CTRL_REG1, 0x0F); // PD bit -> 1 (normal mode); enable X, Y, Z axes
  
  I2C1_Close();
  return(TRUE);
}

/*******************************************************************************
* Function Name  : L3GD20_Write
* Description    : Writes <Data> value into the <Register> address
* Input          : None
* Output         : None
* Return         : Boolean.
*******************************************************************************/
Boolean L3GD20_Write (unsigned char Register, unsigned char Data)
{
  unsigned char Buff[2] = {Register, Data};

  if(FALSE == I2C1_DataTransfer(L3GD20_ADDR, Buff, 2))
  {
    I2C1_Close();
    return(FALSE);
  }
  return TRUE;
}

/*******************************************************************************
* Function Name  : L3GD20_Init
* Description    : Reads <size> bytes from address <Register> stored into <Data>
* Input          : None
* Output         : None
* Return         : Boolean.
*******************************************************************************/
Boolean L3GD20_Read (unsigned char Register, unsigned char *Data, int size)
{
  unsigned char Buff[1] = {Register};

  if(FALSE == I2C1_DataTransfer(L3GD20_ADDR, Buff, 1))
  {
    I2C1_Close();
    return(FALSE);
  }

  if(FALSE == I2C1_DataTransfer(L3GD20_ADDR | 1, Data, size))
  {
    I2C1_Close();
    return(FALSE);
  }
  return TRUE;
}

/*************************************************************************
 * Function Name: L3GD20_Get
 * Parameters: pInt16S pX, pInt16S pY, pInt16S pZ, pInt8S pT
 *
 * Return: Boolean
 *
 * Description: Read X,Y,Z,T data
 *
 *************************************************************************/
Boolean L3GD20_Get (pInt16S pX, pInt16S pY, pInt16S pZ, pInt8S pT)
{
  u8 Data;

  if(FALSE == I2C1_Open())
    return(FALSE);

  // Read temperature
  L3GD20_Read (OUT_TEMP, &Data, 1);
  *pT = Data;

  // Read X value
  L3GD20_Read (OUT_X_L, &Data, 1);
  *pX = Data;
  L3GD20_Read (OUT_X_H, &Data, 1);
  *pX = (*pX) | (Data<<8);

  // Read Y value
  L3GD20_Read (OUT_Y_L, &Data, 1);
  *pY = Data;
  L3GD20_Read (OUT_Y_H, &Data, 1);
  *pY = (*pY) | (Data<<8);

  // Read Z value
  L3GD20_Read (OUT_Z_L, &Data, 1);
  (*pZ) = Data;
  L3GD20_Read (OUT_Z_H, &Data, 1);
  (*pZ) = (*pZ) | (Data<<8);
  
  I2C1_Close();

  return(TRUE);
}

