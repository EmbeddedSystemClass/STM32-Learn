/***************************************************************************
 **
 **
 **    Master include file
 **
 **    Used with ARM IAR C/C++ Compiler
 **
 **    (c) Copyright IAR Systems 2007
 **
 **    $Revision: 48478 $
 **
 ***************************************************************************/

#ifndef __INCLUDES_H
#define __INCLUDES_H

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <intrinsics.h>
#include <assert.h>
#include <math.h>
#include <stdint.h>
#include <yfuns.h>

#include "arm_comm.h"
#include "stm32f4xx_conf.h"

#include "OLIMEX STM32-E407.h"
#include "L3GD20_drv.h"
#include "i2c1_drv.h"

#endif  // __INCLUDES_H
