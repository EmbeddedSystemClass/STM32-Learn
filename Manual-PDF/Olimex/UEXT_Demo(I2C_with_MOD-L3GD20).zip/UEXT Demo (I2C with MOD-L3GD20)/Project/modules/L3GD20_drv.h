/*************************************************************************
 *
 *    Used with IAR for ARM 6.30.7
 *
 *    File name   : L3GD20_drv.h
 *    Description : Gyroscope L3GD20 driver header file
 *
 *    History :
 *    1. Date        : June 28, 2013
 *       Author      : Stanimir Petev
 *       Description : Create.
 *                     Based on Accelerometer sensor LIS3L020 driver header file
 *                     by Stanimir Bonev
 *
 **************************************************************************/

#include "includes.h"

#ifndef L3GD20_DRV_H
#define L3GD20_DRV_H

#define L3GD20_ADDR     (0x6A<<1)

typedef enum _L3GD20_regs_t
{
  WHO_AM_I = 0x0F,
  CTRL_REG1 = 0x20,
  CTRL_REG2,
  CTRL_REG3,
  CTRL_REG4,
  CTRL_REG5, 
  REFERENCE,
  OUT_TEMP,
  STATUS_REG,
  OUT_X_L,
  OUT_X_H,
  OUT_Y_L,
  OUT_Y_H,
  OUT_Z_L,
  OUT_Z_H,
  FIFO_CTRL_REG,
  FIFO_SRC_REG, 
  INT1_CFG,
  INT1_SRC,
  INT1_TSH_XH,
  INT1_TSH_XL,
  INT1_TSH_YH,
  INT1_TSH_YL,
  INT1_TSH_ZH,
  INT1_TSH_ZL,
  INT1_DURATION
} Accl_regs_t;

/*************************************************************************
 * Function Name: L3GD20_Init
 * Parameters: none
 *
 * Return: Boolean
 *
 * Description: Init Accelerometer sensor
 *
 *************************************************************************/
Boolean L3GD20_Init (void);

/*******************************************************************************
* Function Name  : L3GD20_Write
* Description    : Writes <Data> value into the <Register> address
* Input          : None
* Output         : None
* Return         : Boolean.
*******************************************************************************/
Boolean L3GD20_Write (unsigned char Register, unsigned char Data);

/*******************************************************************************
* Function Name  : L3GD20_Init
* Description    : Reads <size> bytes from address <Register> stored into <Data>
* Input          : None
* Output         : None
* Return         : Boolean.
*******************************************************************************/
Boolean L3GD20_Read (unsigned char Register, unsigned char *Data, int size);

/*************************************************************************
 * Function Name: L3GD20_Get
 * Parameters: pInt16S pX, pInt16S pY, pInt16S pZ
 *
 * Return: Boolean
 *
 * Description: Read X,Y,Z,T data
 *
 *************************************************************************/
Boolean L3GD20_Get (pInt16S pX, pInt16S pY, pInt16S pZ, pInt8S pT);

#endif // L3GD20_DRV_H
