This project demonstrates the I2C functionality on the UEXT using MOD-L3GD20 gyroscope module. The example is conducted with the help of either STM32-H407 or STM32-E407.

In order to work connect the module to the UEXT connector with UEXT cable and J-LINK to program the board. Open the workspace "UEXT Demo (I2C with MOD-L3GD20).eww". This project is built with IAR version 6.30.7.

Before building the project you can choose where the results will be printed:

0) On the Terminal I/O of the IAR if you choose configuration Olimex STM32-H407 or Olimex STM32-E407 (depending on your board) IAR IDE Console. In this case you have to open Terminal I/O window after loading the program. You can do it from the Main menu -> View -> Terminal I/O.

1) Otherwise if you have a USB serial cable you can output the results on console program like PuTTY, Hyper Terminal etc. Olimex STM32-E407 UART Console. Configurations are:

Baud rate:	115200
Data bits:	8
Stop bits:	1
Parity:		None